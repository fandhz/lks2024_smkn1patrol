const { DynamoDBClient, PutItemCommand } = require('@aws-sdk/client-dynamodb');

const client = new DynamoDBClient({ region: 'ap-southeast-1' });

exports.handler = async (event) => {
    const { connectionId } = event.requestContext;

    const params = {
        TableName: process.env.table,
        Item: {
            connectionId: { S: connectionId }
        }
    };

    try {
        await client.send(new PutItemCommand(params));
        return { statusCode: 200, body: 'Connected.' };
    } catch (error) {
        console.error("Error while saving connectionId:", error);
        return { statusCode: 500, body: 'Internal Server Error' };
    }
};
