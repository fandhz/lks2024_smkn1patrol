exports.handler = async (event) => {
    console.log("Default route triggered:", event);
    return {
        statusCode: 200,
        body: "Default route executed."
    };
};
