const { DynamoDBClient, ScanCommand, DeleteItemCommand } = require('@aws-sdk/client-dynamodb');
const { ApiGatewayManagementApiClient, PostToConnectionCommand } = require("@aws-sdk/client-apigatewaymanagementapi");

const ddbClient = new DynamoDBClient({ region: 'ap-southeast-1' });

exports.handler = async (event) => {
    const TABLE = process.env.table;
    const domain = event.requestContext.domainName;
    const stage = event.requestContext.stage;

    const apiClient = new ApiGatewayManagementApiClient({
        endpoint: `https://${domain}/${stage}`
    });

    const senderConnectionId = event.requestContext.connectionId;  // ambil pengirim!

    const body = JSON.parse(event.body);
    const message = body.data;

    let connections;
    try {
        const data = await ddbClient.send(new ScanCommand({
            TableName: TABLE,
            ProjectionExpression: 'connectionId'
        }));
        connections = data.Items;
    } catch (err) {
        console.error("Error scanning connections:", err);
        return { statusCode: 500, body: "Error retrieving connections." };
    }

    const postCalls = connections.map(async (conn) => {
        const connectionId = conn.connectionId.S;

        // 🔥 Skip pengirim! Jangan kirim ke dia sendiri
        if (connectionId === senderConnectionId) {
            return;
        }

        try {
            await apiClient.send(new PostToConnectionCommand({
                ConnectionId: connectionId,
                Data: Buffer.from(message)
            }));
        } catch (err) {
            if (err.name === 'GoneException') {
                console.log(`Stale connection, deleting: ${connectionId}`);
                await ddbClient.send(new DeleteItemCommand({
                    TableName: TABLE,
                    Key: { connectionId: { S: connectionId } }
                }));
            } else {
                console.error(`Failed to send message to ${connectionId}:`, err);
            }
        }
    });

    try {
        await Promise.all(postCalls);
        return { statusCode: 200, body: "Message sent." };
    } catch (err) {
        console.error("Failed to send message batch:", err);
        return { statusCode: 500, body: "Sending failed." };
    }
};
