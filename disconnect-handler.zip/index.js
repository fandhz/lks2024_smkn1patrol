const { DynamoDBClient, DeleteItemCommand } = require('@aws-sdk/client-dynamodb');

const client = new DynamoDBClient({ region: 'ap-southeast-1' });

exports.handler = async (event) => {
    const { connectionId } = event.requestContext;

    const params = {
        TableName: process.env.table,
        Key: {
            connectionId: { S: connectionId }
        }
    };

    try {
        await client.send(new DeleteItemCommand(params));
        return { statusCode: 200, body: 'Disconnected.' };
    } catch (error) {
        console.error("Error while deleting connectionId:", error);
        return { statusCode: 500, body: 'Internal Server Error' };
    }
};
